<?php

namespace App\Controller;

use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use App\Entity\{Productos, Contacto};
use App\Repository\ProductosRepository;
use Symfony\Component\Routing\Annotation\Route;
use App\Form\ContactaType;
class ServiceController extends AbstractController
{
    /**
    * @Route("/", name="index")
    */
    // Con esta función hago que haga render de la página principal
    public function index()
    {
        return $this->render('service/index.html.twig');
    }
    /**
    * @Route("/servicios", name="servicios")
    */
    // Con esta función hago que haga render de la página de servicios
    public function servicios()
    {
       return $this->render('service/servicios.html.twig');
    }
    /**
    * @Route("/productos/{currentPage?1}", name="productos")
    */
    // Con esta función hago que haga render de la página de productos y cuando la variable page cambie a 2 haga render de ésta,
    // también hace que si la url cambia a cualquier otro numero o nombre me redirija a la primera página de productos
    public function productos($currentPage, ProductosRepository $ProductosRepository)
    {
        return $this->render('service/productos.html.twig',[
            'currentPage' => $currentPage,
            'data' => $proyecto=$this->getDoctrine()->getRepository(productos::Class)->findall(),
        ]);
    }
  /**
    * @Route("/detalle/{detalle}", name="detalle")
    */
    public function detalle($detalle)
    {
        return $this->render('service/detalle.html.twig',[
            'detalle' => $detalle,
            'data' => $proyecto=$this->getDoctrine()->getRepository(productos::Class)->findall(),
        ]);
    }
    /**
    * @Route("/nosotros", name="nosotros")
    */
    // Con esta función hago que haga render de la página de nosotros
    public function nosotros()
    {
        return $this->render('service/nosotros.html.twig');
    }
    /**
    * @Route("/contacto", name="contacto")
    */
    // Con esta función hago que haga render de la página de contacto
    public function contacto(Request $request)
    {
        $contactoBBDD=$this->getDoctrine()->getRepository(Contacto::Class)->findAll();
        $contacto=new Contacto();
        $form=$this->CreateForm(ContactaType::Class, $contacto);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $entityManager=$this->getDoctrine()->getManager();
            $entityManager->persist($contacto);
            $entityManager->flush();}
        return $this->render('service/contacto.html.twig', [
            'form' => $form->CreateView(),
            'contactobbdd' => $contactoBBDD,
        ]);

    }
    /**
    * @Route("/contacto/preview", name="contacto2")
    */
    // Con esta función hago que haga render de la página de contacto2 y pida los
    public function send(Request $request)
    {
        $nombre = $request->request->get('name');
        $email = $request->request->get('email');
        $website = $request->request->get('website');
        $asunto = $request->request->get('subject');
        $mensaje = $request->request->get('message');
        if ($website == 0){
            $website = "Campo vacío";
        }
        if ($asunto == 0){
            $asunto = "Campo vacío";
        }
        return $this->render('service/contacto2.html.twig', [
            'nombre' => $nombre,
            'email' => $email,
            'website' => $website,
            'asunto' => $asunto,
            'mensaje' => $mensaje,
        ]);
    }
    /**
    * @Route("/login", name="login")
    */
    // Aquí se ve si el usuario esta conectado o no
    public function login(SessionInterface $session)
    {
        $login = $session->get('username');
        if ($login != "") {
            $mensaje = "Usuario ".$login." conectado.";
        } else {
            $mensaje = "Introduce tus datos de usuario para iniciar la sesión.";
        }
        return $this->render('service/login.html.twig', [
            'mensajesesion' => $mensaje,
            'login' => $login
        ]);
    }
    /**
    * @Route("/loggedin", name="logging")
    */
    // Aquí se creara la sesión
    public function logging(Request $request, SessionInterface $session)
    {
        $login = $request->request->get('user'); 
        if ($login != "") {
            $session->set('username', $login);
            $mensaje = "Usuario ".$login." conectado.";
        } else {
            $mensaje = "Introduce tus datos de usuario para iniciar la sesión.";
        }
        return $this->render('service/login.html.twig', [
            'mensajesesion' => $mensaje,
            'login' => $login
        ]);
    }
    /**
    * @Route("/logout", name="logout")
    */
    // Aqui el usuario se desloguea
    public function logout(SessionInterface $session)
    {
        $session->clear();
        $session->invalidate();
        return $this->redirectToRoute('index');
    }
}
